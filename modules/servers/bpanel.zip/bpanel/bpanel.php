<?php

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

function bpanel_MetaData()
{
    return [
        'DisplayName' => 'BPanel Hosting',
        'APIVersion' => '1.1',
        'RequiresServer' => true,
    ];
}

function bpanel_ConfigOptions()
{
    return [
        'Package' => [
            'Type' => 'text',
            'Size' => '25',
            'Loader' => 'bpanel_PackageLoader',
            'SimpleMode' => true,
            'Default' => '1',
            'Description' => 'Select a BPanel package',
        ],
        'App Type' => [
            'Type' => 'dropdown',
            'Options' => 'php,static,wordpress',
            'Default' => 'php',
        ],
        'PHP Version' => [
            'Type' => 'dropdown',
            'Options' => '8.4,8.3,8.2,8.1,8.0,7.4,5.6',
            'Default' => '8.4',
        ],
        'Install WordPress' => [
            'Type' => 'yesno',
            'Description' => 'Install WordPress during provisioning',
        ],
        'Auto SSL' => [
            'Type' => 'yesno',
            'Description' => 'Request Let\'s Encrypt SSL after provisioning',
        ],
    ];
}

function bpanel_PackageLoader($params)
{
    $result = bpanel_request($params, 'GET', '/api/provisioning/v1/plans');
    if (!$result['ok']) {
        throw new Exception($result['error']);
    }

    return bpanel_package_options($result['data']);
}

function bpanel_TestConnection($params)
{
    $result = bpanel_request($params, 'GET', '/api/provisioning/v1/plans');
    return $result['ok'] ? ['success' => true] : ['success' => false, 'error' => $result['error']];
}

function bpanel_CreateAccount($params)
{
    $domain = bpanel_domain($params);
    $username = bpanel_provision_username($params);
    $password = bpanel_password($params);
    $payload = [
        'external_id' => bpanel_external_id($params),
        'username' => $username,
        'password' => $password,
        'package_id' => (int) bpanel_config($params, 1, '1'),
        'php_version' => bpanel_config($params, 3, '8.4'),
        'app_type' => $domain === '' ? 'php' : bpanel_config($params, 2, 'php'),
        'install_wordpress' => bpanel_yesno(bpanel_config($params, 4, '')),
        'enable_ssl' => bpanel_yesno(bpanel_config($params, 5, '')),
    ];

    if ($domain !== '') {
        $payload['domain'] = $domain;
    }

    if ($payload['install_wordpress']) {
        $payload['app_type'] = 'wordpress';
    }
    if ($domain === '' && ($payload['install_wordpress'] || $payload['enable_ssl'])) {
        return 'A domain is required when Install WordPress or Auto SSL is enabled';
    }

    $result = bpanel_request($params, 'POST', '/api/provisioning/v1/accounts', $payload);
    if (!$result['ok']) {
        return $result['error'];
    }

    $accountUsername = trim((string) ($result['data']['username'] ?? $username));
    bpanel_save_service_record($params, $result['data'], $accountUsername, $password);
    return 'success';
}

function bpanel_SuspendAccount($params)
{
    $payload = ['reason' => $params['suspendreason'] ?? 'Suspended by WHMCS'];
    $result = bpanel_request($params, 'POST', '/api/provisioning/v1/accounts/' . rawurlencode(bpanel_external_id($params)) . '/suspend', $payload);
    return $result['ok'] ? 'success' : $result['error'];
}

function bpanel_UnsuspendAccount($params)
{
    $result = bpanel_request($params, 'POST', '/api/provisioning/v1/accounts/' . rawurlencode(bpanel_external_id($params)) . '/unsuspend');
    return $result['ok'] ? 'success' : $result['error'];
}

function bpanel_TerminateAccount($params)
{
    $result = bpanel_request($params, 'DELETE', '/api/provisioning/v1/accounts/' . rawurlencode(bpanel_external_id($params)), null, ['backup' => 'true']);
    return $result['ok'] ? 'success' : $result['error'];
}

function bpanel_ChangePassword($params)
{
    $payload = ['password' => bpanel_password($params)];
    $result = bpanel_request($params, 'PATCH', '/api/provisioning/v1/accounts/' . rawurlencode(bpanel_external_id($params)) . '/password', $payload);
    return $result['ok'] ? 'success' : $result['error'];
}

function bpanel_ChangePackage($params)
{
    $payload = ['package_id' => (int) bpanel_config($params, 1, '1')];
    $result = bpanel_request($params, 'PATCH', '/api/provisioning/v1/accounts/' . rawurlencode(bpanel_external_id($params)) . '/package', $payload);
    return $result['ok'] ? 'success' : $result['error'];
}

function bpanel_UsageUpdate($params)
{
    if (empty($params['serviceid'])) {
        return 'success';
    }

    $result = bpanel_request($params, 'GET', '/api/provisioning/v1/accounts/' . rawurlencode(bpanel_external_id($params)) . '/usage');
    if (!$result['ok']) {
        return $result['error'];
    }

    bpanel_save_service_note($params, $result['data']);
    return 'success';
}

function bpanel_LoginLink($params)
{
    $url = bpanel_sso_url($params);
    return '<a href="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" target="_blank">Login to BPanel</a>';
}

function bpanel_ClientArea($params)
{
    $account = [];
    if (!empty($params['serviceid'])) {
        $result = bpanel_request($params, 'GET', '/api/provisioning/v1/accounts/' . rawurlencode(bpanel_external_id($params)));
        if ($result['ok']) {
            $account = $result['data'];
        }
    }

    return [
        'templatefile' => 'clientarea',
        'vars' => [
            'panelUrl' => bpanel_base_url($params),
            'loginUrl' => bpanel_sso_url($params),
            'username' => bpanel_username($params),
            'serviceLabel' => bpanel_service_label($params, $account),
            'packageName' => trim((string) ($account['package_name'] ?? '')),
            'domain' => trim((string) ($account['domain'] ?? '')),
            'status' => trim((string) ($account['status'] ?? '')),
        ],
    ];
}

function bpanel_request($params, $method, $path, $payload = null, $query = [])
{
    if (!function_exists('curl_init')) {
        return ['ok' => false, 'error' => 'PHP cURL extension is required'];
    }

    $token = trim((string) ($params['serveraccesshash'] ?? ''));
    if ($token === '') {
        $token = trim((string) ($params['serverpassword'] ?? ''));
    }
    if ($token === '') {
        return ['ok' => false, 'error' => 'Missing BPanel API token in server Access Hash or Password'];
    }

    $url = bpanel_base_url($params) . $path;
    if ($query) {
        $url .= '?' . http_build_query($query);
    }

    $headers = [
        'Authorization: Bearer ' . $token,
        'Accept: application/json',
    ];

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => strtoupper($method),
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_TIMEOUT => 90,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);

    if ($payload !== null) {
        $body = json_encode($payload);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }

    $body = curl_exec($ch);
    $errno = curl_errno($ch);
    $error = curl_error($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($errno) {
        bpanel_log($params, $method, $path, $payload, null, 'cURL ' . $errno . ': ' . $error);
        return ['ok' => false, 'error' => 'BPanel connection failed: ' . $error];
    }

    $data = json_decode((string) $body, true);
    if ($status < 200 || $status >= 300) {
        $message = is_array($data) && isset($data['detail']) ? $data['detail'] : (string) $body;
        bpanel_log($params, $method, $path, $payload, $body, 'HTTP ' . $status . ': ' . $message);
        return ['ok' => false, 'error' => 'BPanel API error: ' . $message];
    }

    bpanel_log($params, $method, $path, $payload, $body, 'OK');
    return ['ok' => true, 'data' => is_array($data) ? $data : []];
}

function bpanel_base_url($params)
{
    $hostname = trim((string) ($params['serverhostname'] ?? ''));
    if ($hostname === '') {
        $hostname = trim((string) ($params['serverip'] ?? ''));
    }
    $hostname = preg_replace('#^https?://#', '', $hostname);
    $hostname = rtrim($hostname, '/');

    $secure = !empty($params['serversecure']);
    $scheme = $secure ? 'https' : 'http';
    $port = trim((string) ($params['serverport'] ?? ''));

    if ($port !== '' && !in_array($port, ['80', '443'], true)) {
        return $scheme . '://' . $hostname . ':' . $port;
    }

    return $scheme . '://' . $hostname;
}

function bpanel_external_id($params)
{
    return 'whmcs:' . (int) ($params['serviceid'] ?? 0);
}

function bpanel_username($params)
{
    $username = trim((string) ($params['username'] ?? ''));
    if ($username !== '' && preg_match('/^[a-z_][a-z0-9_-]{2,31}$/', $username)) {
        return $username;
    }

    $serviceId = (int) ($params['serviceid'] ?? 0);
    return bpanel_random_username($serviceId);
}

function bpanel_provision_username($params)
{
    $serviceId = (int) ($params['serviceid'] ?? 0);
    return bpanel_random_username($serviceId);
}

function bpanel_password($params)
{
    $password = (string) ($params['password'] ?? '');
    if (strlen($password) >= 12 && strlen($password) <= 72) {
        return $password;
    }

    return bpanel_random_string(24, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789');
}

function bpanel_domain($params)
{
    return strtolower(trim((string) ($params['domain'] ?? '')));
}

function bpanel_config($params, $index, $default)
{
    $key = 'configoption' . $index;
    $value = $params[$key] ?? $default;
    return trim((string) $value) !== '' ? trim((string) $value) : $default;
}

function bpanel_yesno($value)
{
    return in_array(strtolower(trim($value)), ['on', 'yes', 'true', '1'], true);
}

function bpanel_package_options($packages)
{
    if (!is_array($packages)) {
        throw new Exception('BPanel package list response is invalid');
    }

    $options = [];
    foreach ($packages as $package) {
        if (!is_array($package)) {
            continue;
        }

        $id = (int) ($package['id'] ?? 0);
        if ($id <= 0) {
            continue;
        }

        $name = trim((string) ($package['name'] ?? ''));
        if ($name === '') {
            $name = 'Package ' . $id;
        }

        $options[(string) $id] = $name . ' (#' . $id . ')';
    }

    if ($options === []) {
        throw new Exception('No BPanel packages found');
    }

    return $options;
}

function bpanel_service_label($params, $account)
{
    if (is_array($account) && !empty($account['service_label'])) {
        return (string) $account['service_label'];
    }

    $product = trim((string) ($params['productname'] ?? ''));
    if ($product === '') {
        $product = 'BPanel Hosting';
    }

    $serviceId = (int) ($params['serviceid'] ?? 0);
    return $serviceId > 0 ? $product . ' #' . $serviceId : $product;
}

function bpanel_sso_url($params)
{
    if (empty($params['serviceid'])) {
        return bpanel_base_url($params);
    }

    $result = bpanel_request($params, 'POST', '/api/provisioning/v1/accounts/' . rawurlencode(bpanel_external_id($params)) . '/login');
    if ($result['ok'] && !empty($result['data']['url'])) {
        $url = trim((string) $result['data']['url']);
        if (preg_match('#^https?://#i', $url)) {
            return $url;
        }
        return rtrim(bpanel_base_url($params), '/') . '/' . ltrim($url, '/');
    }

    return bpanel_base_url($params);
}

function bpanel_save_service_record($params, $data, $username = '', $password = '')
{
    if (!function_exists('localAPI') || empty($params['serviceid'])) {
        return;
    }

    $lines = ['BPanel'];
    foreach (['service_label', 'external_id', 'username', 'email', 'domain', 'status', 'package_id', 'package_name', 'storage_used_bytes', 'storage_limit_bytes', 'storage_percent'] as $key) {
        if (array_key_exists($key, $data)) {
            $lines[] = $key . ': ' . (is_scalar($data[$key]) ? $data[$key] : json_encode($data[$key]));
        }
    }

    $update = [
        'serviceid' => (int) $params['serviceid'],
        'notes' => implode("\n", $lines),
    ];
    if ($username !== '') {
        $update['serviceusername'] = $username;
    }
    if ($password !== '') {
        $update['servicepassword'] = $password;
    }

    try {
        localAPI('UpdateClientProduct', $update);
    } catch (Throwable $e) {
        // WHMCS record update is best effort; provisioning already succeeded.
    }
}

function bpanel_save_service_note($params, $data)
{
    bpanel_save_service_record($params, $data);
}

function bpanel_random_username($serviceId)
{
    $prefix = 'bp' . max(0, (int) $serviceId) . '_';
    return substr($prefix . bpanel_random_string(8, 'abcdefghijklmnopqrstuvwxyz0123456789'), 0, 32);
}

function bpanel_random_string($length, $alphabet)
{
    $result = '';
    $max = strlen($alphabet) - 1;
    for ($i = 0; $i < $length; $i++) {
        $result .= $alphabet[random_int(0, $max)];
    }
    return $result;
}

function bpanel_log($params, $method, $path, $request, $response, $result)
{
    if (!function_exists('logModuleCall')) {
        return;
    }

    $replaceVars = [trim((string) ($params['serveraccesshash'] ?? '')), trim((string) ($params['serverpassword'] ?? ''))];
    if (is_array($request) && isset($request['password'])) {
        $replaceVars[] = (string) $request['password'];
    }

    logModuleCall(
        'bpanel',
        $method . ' ' . $path,
        $request,
        $response,
        $result,
        $replaceVars
    );
}
